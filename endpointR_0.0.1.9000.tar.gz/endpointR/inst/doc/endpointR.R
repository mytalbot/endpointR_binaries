## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(endpointR)
a      <- 1
td     <- ep_select(gliodat, a) 
danger <- epR(td        = td,
              org       = FALSE,
              wl        = 6,
              SDwdth    = 2,
              mad       = FALSE,
              cex       = 1.4,
              cex.lab   = 1.2,
              blind     = FALSE,
              ignupr    = FALSE,
              ylim      = c(90,105), 
              xlim      = c(0,28),
              xlab      = "day")
danger

